public class BankAccount {
    private String acoountNumber;
    private String accountHolderName;
    private int balance;
    private int dailyWithdrawlimit;
    private int totalWithdrawToday;
    private boolean isLocked;
    private int failedAttempts;
    // empty constructor/ default constructor
    BankAccount(){}
    BankAccount(String accNum, String name,int balance , int limit){
        this.acoountNumber= accNum;
        this.accountHolderName = name;
        this.balance= balance;
        this.dailyWithdrawlimit = limit;
        this.totalWithdrawToday =0;
        this.isLocked=false;
        this.failedAttempts=0;
    }
    // deposit
    public boolean deposit(int money){
        if(isLocked)
        {
            System.out.println("Account is blocked. Cannot deposit money");
            return false;
        }
        if(money<0)
        {
            System.out.println("Money cannot be deposited.");
            return false;
        }
        balance+=money;
        System.out.println("Money has deposited.");
        return true;
    }
    // withdraw method and validation
    public boolean withdraw(int money)
    {
        if(isLocked)
        {
             System.out.println("Account is blocked. Cannot deposit money");
             return false;
        }
        
        if(totalWithdrawToday+money>dailyWithdrawlimit)
        {
            System.out.println("Limit exceeds.");
            failedAttempts++;
        }
        else if(money>balance)
        {
           System.out.println("Insuficient balance.");
           failedAttempts++;
        }
        else{
           balance-=money;
            totalWithdrawToday+=money;
            failedAttempts =0;
            System.out.println("Withdraw successful");
            return true;
        }
        
        if(failedAttempts>=3)
        {
            isLocked = true;
            System.out.println("Account has blocked.");
        }
           return false; 
        
    }
    // transfer money method
    public void transfer(BankAccount receiver , int money)
    {
        if(this.withdraw(money))
        {
            boolean success = receiver.deposit(money);
            if(!success)
            {
                // money back in depositor account
                this.deposit(money);
                System.out.println("Transfer failed. money refunded.");
                return;
            }
            System.out.println("Transfer successful.");
            
        }    
    }        
    
    
    
    
}
