 public class Main {
    public static void main(String[] args) {
       BankAccount acc1 = new BankAccount("001","Ali",50000,20000);
        BankAccount acc2 = new BankAccount("002","Asghar",30000,10000);
        acc1.withdraw(5000);
        acc1.transfer(acc2, 1000);
    }
    
}
